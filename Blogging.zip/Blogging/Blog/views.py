from django.shortcuts import render,redirect


# Create your views here.
from django.http import HttpResponse
from django.contrib.auth.models import auth
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from .models import Bloger
#from .models import Bloger
#Create your views here.
def index(request):
    return render(request,'front.html',{'name':'Hi i am new to django Dynamically Attaching'})
def signin(request):

    if request.method=='POST':
        bname=request.POST['bname']
        password=request.POST['password']
        blogger=auth.authenticate(Bloger(bname=bname,password=password))


        if Bloger.objects.filter(bname=bname).exists() and Bloger.objects.filter(password=password).exists() :

            auth.login(request,blogger)
            messages.info(request,"login success")
            return redirect("signup")
        else:
            messages.info(request,"Wrong Blogger name or password")
            return redirect('signin')
    else:
        return render(request,'sign-in.html',{'name':'Hi i am new to django Dynamically Attaching'})









def signup(request):
    if request.method == 'POST':
        bname=request.POST['bname']
        email=request.POST['email']
        password=request.POST['password']
        password2=request.POST['password2']
        if password==password2:
            if Bloger.objects.filter(bname=bname).exists():
                print("Username Already Taken")
                return render(request,'sign-up.html')
            elif Bloger.objects.filter(email=email).exists():

                print("Email Already Taken")
                return render(request,'sign-up.html')
            else:
                bloger=Bloger(bname=bname,email=email,password=password)
                bloger.save();
                print("User Created")
                return render(request,'sign-in.html')
        else:

            print("Password Does not match")
            return render(request,'sign-up.html')
    else:
        return render(request,'sign-up.html',{'name':'Hi i am new to django Dynamically Attaching'})
