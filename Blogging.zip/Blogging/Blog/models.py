from django.db import models

# Create your models here.
class Bloger(models.Model):

    bname=models.CharField(max_length=200,unique='True')
    email=models.EmailField(max_length=300)
    password=models.CharField(max_length=300)
    password2=models.CharField(max_length=300)
    is_anonymous="True"
    is_authenticated="false"

    USERNAME_FIELD="bname"


    REQUIRED_FIELDS=['email','password','password2']
