from django.urls import path
from . import views

urlpatterns = [
    path('front.html',views.index,name="index"),
    path('',views.index,name="index"),
    path('sign-in.html',views.signin,name="signin"),
    path('sign-up.html',views.signup,name="signup"),
]
